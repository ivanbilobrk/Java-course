package hr.fer.oprpp1.hw02.prob1;

/**
 * Enumeration which specifies all states a lexer can be in.
 * @author Ivan Bilobrk
 * @version 1.0
 */
public enum LexerState {
	BASIC, EXTENDED
}

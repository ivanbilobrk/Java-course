package hr.fer.zemris.java.hw05.shell;

/**
 * Enum with two constants representing current shell status.
 * @author Ivan Bilobrk
 *
 */
public enum ShellStatus {
	CONTINUE, TERMINATE
}
